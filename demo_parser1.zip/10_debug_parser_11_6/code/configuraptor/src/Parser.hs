-- Do not modify this file. Place your parser code in ParserImpl.hs

module Parser (parseString) where

import ParserImpl
