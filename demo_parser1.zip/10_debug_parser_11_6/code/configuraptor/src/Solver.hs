-- Do not modify this file. Place your solver code in SolverImpl.hs

module Solver (combine, verify, solve) where

import SolverImpl

