module ElaboratorImpl where

import Absyn
-- add other imports

lookres :: [Resource] -> RName -> Either ErrMsg Resource
lookres = undefined

elaborate :: IDB -> Either ErrMsg DB
elaborate = undefined
