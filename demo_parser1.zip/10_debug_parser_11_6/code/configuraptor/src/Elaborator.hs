-- Do not modify this file. Place your elaborator code in ElaboratorImpl.hs

module Elaborator (lookres, elaborate) where

import ElaboratorImpl
