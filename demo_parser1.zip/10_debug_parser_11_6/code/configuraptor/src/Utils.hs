module Utils where

-- Put any code that you need to share between two or more modules here
